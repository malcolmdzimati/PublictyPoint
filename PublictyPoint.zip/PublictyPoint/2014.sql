SELECT * FROM Passengers WHERE Destination = "Cape Town"
SELECT BaggageType FROM Baggage GROUP BY BaggageType 
# SELECT DISTINCT BaggageType FROM Baggage
INSERT INTO Claims(ClaimID, BaggageID, Description) VALUES(16, 240402,"Theft")
DELETE * FROM Baggage WHERE PassengerID=14
UPDATE Claims SET Reference = LEFT(Description,2) & RIGHT(BaggageID,4)
SELECT SUM(Weight) AS TotalWeight, PassengerID FROM Baggage GROUP BY PassengerID ORDER BY SUM(Weight) DESC
SELECT Fullname, InsuredVaule, Weight FROM Baggage INNER JOIN Passengers ON Baggage.PassengerID = Passengers.PassengerID
WHERE BaggageType = "Sport Equipment" OR BaggageType = "Other"
SELECT Fullname  FROM Passengers WHERE PassengerID NOT IN(SELECT PassengerID FROM Baggage)
SELECT Fullname FROM Passengers INNER JOIN Baggage ON Passenegers.PassengerID = Baggage.PassengerID WHERE Baggage.PassengerID = null
SELECT * FROM Baggage WHERE CheckInCounter = 6 AND InsuredValue > (SELECT AVG(InsuredValue) FROM Baggage) AND Fragile = true